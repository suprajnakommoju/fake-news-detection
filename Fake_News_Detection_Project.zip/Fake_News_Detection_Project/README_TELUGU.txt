FAKE NEWS DETECTION SYSTEM — START HERE
=======================================

Important:
Ee ZIP oka college-project prototype. Included dataset chala chinnadi, demo kosame.
Prediction anedi nijam/fake ani proof kaadu. Real use kosam large, trusted, labelled
dataset, testing, and reliable source verification avasaram.

WINDOWS + VS CODE LO RUN CHEYYADAM
----------------------------------
1. ZIP file ni extract cheyyi.
2. Extract chesina Fake_News_Detection_Project folder ni VS Code lo Open Folder cheyyi.
3. VS Code lo Terminal > New Terminal click cheyyi.
4. Ee commands okkokkati run cheyyi:

   python -m venv .venv
   .venv\Scripts\activate
   python -m pip install -r requirements.txt
   python app.py

5. Terminal lo "Running on http://127.0.0.1:5000" ani vastundi.
6. Chrome lo http://127.0.0.1:5000 open cheyyi.
7. News text paste chesi Analyze news click cheyyi.
8. Aapestanante terminal lo Ctrl+C press cheyyi.

TROUBLESHOOTING
---------------
- "python is not recognized": Python install ayindo check cheyyi; VS Code restart cheyyi.
- Package install error: internet connection check chesi pip command malli run cheyyi.
- Port in use: app.py lo port=5000 ni port=5001 ga change chesi run cheyyi.
- Model error: Terminal lo kanipinche error choodu; requirements install ayinayo verify cheyyi.

FILES
-----
app.py                  Flask server + model loading/training
templates/index.html    Website page
static/style.css        Website design
static/script.js        Analyze button behaviour
data/news_dataset.csv   Small sample dataset
requirements.txt        Python packages

ANDROID APP OPTION — FREE
-------------------------
Beginner-friendly free option: make the website responsive first. To install it like an
app, it needs to be hosted on an HTTPS address and configured as a Progressive Web App.
This starter includes a manifest but does not include offline caching or a service worker.
For a native Android APK, MIT App Inventor can create a WebViewer wrapper, but the Flask
server must be hosted or reachable by the phone. Localhost on the laptop will not work
as localhost on the phone. Hosting may have free limits and can change.

NEXT IMPROVEMENTS
-----------------
1. Replace the tiny demo dataset with a properly licensed, larger labelled dataset.
2. Split data into training and test sets and report precision, recall, F1 and confusion matrix.
3. Add source links and independent fact-checking; don't use model confidence as truth probability.
4. Add user login/history only if needed and protect personal data.
