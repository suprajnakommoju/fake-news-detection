from flask import Flask, render_template, request, jsonify
from pathlib import Path
import csv
import re

app = Flask(__name__)
BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "data" / "news_dataset.csv"

# This small included dataset is ONLY for demonstrating the project workflow.
# It is not large or diverse enough for reliable real-world fact checking.
model = None
vectorizer = None
model_error = None

def train_model():
    global model, vectorizer, model_error
    try:
        import pandas as pd
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.linear_model import LogisticRegression
        from sklearn.pipeline import Pipeline

        df = pd.read_csv(DATA_FILE)
        df = df.dropna(subset=["text", "label"])
        if df["label"].nunique() < 2 or len(df) < 10:
            raise ValueError("Dataset needs at least 10 labelled examples and both labels.")
        model = Pipeline([
            ("tfidf", TfidfVectorizer(stop_words="english", ngram_range=(1, 2), max_features=5000)),
            ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced"))
        ])
        model.fit(df["text"].astype(str), df["label"].astype(str))
        model_error = None
    except Exception as exc:
        model = None
        model_error = str(exc)

train_model()

def basic_input_check(text):
    text = re.sub(r"\s+", " ", text or "").strip()
    if len(text) < 25:
        return None, "Please enter a longer headline or article (at least 25 characters)."
    if len(text) > 10000:
        return None, "Please keep the text under 10,000 characters."
    return text, None

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/analyze", methods=["POST"])
def analyze():
    payload = request.get_json(silent=True) or request.form
    raw_text = payload.get("news", "")
    text, error = basic_input_check(raw_text)
    if error:
        return jsonify({"ok": False, "error": error}), 400

    if model is None:
        return jsonify({
            "ok": False,
            "error": "The model could not be loaded. Check installation and data/news_dataset.csv.",
            "details": model_error
        }), 500

    prediction = str(model.predict([text])[0]).lower()
    confidence = None
    try:
        probabilities = model.predict_proba([text])[0]
        confidence = round(float(max(probabilities)) * 100, 1)
    except Exception:
        pass

    # These are model labels, not verified facts.
    label_map = {
        "real": ("REAL-LIKE", "The model found patterns similar to its labelled REAL examples."),
        "fake": ("FAKE-LIKE", "The model found patterns similar to its labelled FAKE examples.")
    }
    display, explanation = label_map.get(
        prediction, (prediction.upper(), "This is a model prediction, not a verified fact.")
    )
    return jsonify({
        "ok": True,
        "prediction": display,
        "raw_label": prediction,
        "confidence": confidence,
        "explanation": explanation,
        "warning": "This prototype uses a small demo dataset. Do not treat its prediction or confidence as proof. Verify claims with reliable sources."
    })

@app.route("/health")
def health():
    return jsonify({"status": "ok", "model_loaded": model is not None, "model_error": model_error})

if __name__ == "__main__":
    # Local development only. Do not expose Flask's development server publicly.
    app.run(host="127.0.0.1", port=5000, debug=True)
