const news = document.getElementById("news");
const count = document.getElementById("charCount");
const analyzeBtn = document.getElementById("analyzeBtn");
const clearBtn = document.getElementById("clearBtn");
const emptyState = document.getElementById("emptyState");
const loadingState = document.getElementById("loadingState");
const resultState = document.getElementById("resultState");
const errorState = document.getElementById("errorState");

news.addEventListener("input", () => count.textContent = `${news.value.length.toLocaleString()} / 10,000`);
clearBtn.addEventListener("click", () => {
  news.value = "";
  count.textContent = "0 / 10,000";
  news.focus();
  showOnly(emptyState);
});

function showOnly(element) {
  [emptyState, loadingState, resultState, errorState].forEach(item => item.classList.add("hidden"));
  element.classList.remove("hidden");
}

analyzeBtn.addEventListener("click", async () => {
  if (!news.value.trim()) {
    news.focus();
    showError("Please paste a headline or news article first.");
    return;
  }
  analyzeBtn.disabled = true;
  showOnly(loadingState);
  try {
    const response = await fetch("/api/analyze", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({news: news.value})
    });
    const data = await response.json();
    if (!response.ok || !data.ok) throw new Error(data.error || "Could not analyze this text.");
    document.getElementById("prediction").textContent = data.prediction;
    document.getElementById("explanation").textContent = data.explanation;
    document.getElementById("confidence").textContent = data.confidence === null ? "Unavailable" : `${data.confidence}%`;
    document.getElementById("progressBar").style.width = data.confidence === null ? "0%" : `${data.confidence}%`;
    document.getElementById("warning").textContent = data.warning;
    const fakeLike = data.raw_label === "fake";
    document.getElementById("resultSymbol").textContent = fakeLike ? "!" : "✓";
    document.getElementById("resultSymbol").style.background = fakeLike ? "#fee2e2" : "#d1fae5";
    document.getElementById("resultSymbol").style.color = fakeLike ? "#b91c1c" : "#047857";
    document.getElementById("prediction").style.color = fakeLike ? "#b91c1c" : "#047857";
    showOnly(resultState);
  } catch (error) {
    showError(error.message);
  } finally {
    analyzeBtn.disabled = false;
  }
});

function showError(message) {
  errorState.textContent = message;
  showOnly(errorState);
}
